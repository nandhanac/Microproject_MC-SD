package Setdefinition1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepdef {
	WebDriver driver=null;

@Given("browser is open")
public void browser_is_open() {
	    
	    System.setProperty("webdriver.gecko.marionette","/A_3/src/test/resources/drivers/geckodriver-v0.32.2-win-aarch64/geckodriver.exe");
	    driver = new FirefoxDriver();
	    driver.manage().window().maximize();
}

@And("user in on page")
public void user_in_on_page() throws InterruptedException {
	driver.navigate().to("file:///D:/Adm/Wecare/login.html");
	Thread.sleep(2000);
}
    

@When("user enters user name and password")
public void user_enters_user_name_and_password() {
	driver.findElement(By.id("user")).sendKeys("student@gmail.com");
	driver.findElement(By.id("password")).sendKeys("Password12@");
}

@And("enter login button")
public void enter_login_button() {
	driver.findElement(By.id("submit")).click();
   
}

@Then("user is navigated to the home page")
public void user_is_navigated_to_the_home_page() throws InterruptedException {
	driver.findElement(By.id("btn2")).isDisplayed();
	//driver.findElement(By.id("btn2")).isDisplayed();
	Thread.sleep(2000);
	driver.close();
	driver.quit();
	
   
}

}
